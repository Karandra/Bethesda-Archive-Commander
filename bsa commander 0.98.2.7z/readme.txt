BSA Commander Version 0.98.2
Work with oblivion archive files (.bsa) with friendly interface.
--------------------------------------------------------------------------------------------
(sorry for my bad english)

With BSA Commander you can:

  - view content of .bsa files;
  - get detailed info about archive and save it to file;
  - unpack files from archive (all files or any of them);
  - register archive files for game;
  - create new .bsa archives;
  - you may associate BSA Commander to .bsa files
  - BSA commander may work as command line utility

PS: I don't have complete info about Archive Flags and Files Flags in .bsa header. You need
enter their values manually. If you create compressed archive, it force to setting bit 3 in
Archive Flags.

[0.96]
  FIX: individual compression file bug.
[0.97]
  FIX: files and dirs order
  ADD: flags wizards
[0.98]
  ADD: command line mode
[0.98.2]
  ADD: sort list of files in various modes
  FIX: updated version of ZLIB - solve some troubles

Usage BSA Commander in command line mode:
>bsacmd [cmd] [params...]
where commands is:
  -? or -help
    show this text

  -pack "SourceDir" "OutputFileName" [other_params...]
    pack files from source dir to output bsa archive
    additional params:
     -r=0       - recursive subdirs (default)
     -r=1       - not recursive subdirs
     -l=0       - without compression (default)
     -l=1       - default compression level
     -l=2       - fastest compression level
     -l=3       - max compression level
     -af=FFFFFF - hex value of archive flags
     -ff=FFFFFF - hex value of files flags

  -unpack "SourceFileName" "OutputDir"
    unpack files from source bsa archive to output dir

  -list "SourceFileName" ["OutputFileName"]
    list files from source bsa archive to output log file
    if output file not specified it will be created in same folder as src file

for example:
>bsacmd -help
>bsacmd -list "C:\Program Files\Oblivion\Data\Oblivion - Misc.bsa" "C:\misc.log"
>bsacmd -pack "C:\MyMod\" "C:\BSA\MyMod.bsa" -r=0 -l=3 -af=707 -ff=1A4
>bsacmd -unpack "C:\BSA\MyMod.bsa" "C:\temp\"

Attention: New archives must be registered in oblivion.ini BEFORE standard archives.

Notes:
 1. Describe full quality path for input and output files and folders. Use "..."
    buttons to browse your HDD. For example "C:\temp\mymod.bsa" instead of "mymod.bsa".
    Otherwise you'll get error message "Incorrect params".
 2. Use flags wizards to detect correct flags value. Use "?" buttons to invoke it.
 3. Retexture task possible require changing file "ArchiveInvalidation.txt"
 4. Check textures in your .nif files. There is difference in slashes "\" and "/".
    See documentation in your nif tool.

Also check additional tutorials:
http://cs.elderscrolls.com/constwiki/index.php/Creating_your_Own_BSA_files
http://cs.elderscrolls.com/constwiki/index.php/Retexturing_Made_Easy
http://cs.elderscrolls.com/constwiki/index.php/Retex_Troubleshooting

--------------------------------------------------------------------------------------------
SOFTWARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.

AUTHOR DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, WITH
RESPECT TO THE PROGRAM. THE END-USER ASSUMES ALL RISK AS TO THE SUITABILITY, QUALITY,
AND PERFORMANCE OF THE PROGRAM. IN NO EVENT WILL AUTHOR, OR ITS DIRECTORS, OFFICERS,
EMPLOYEES OR AFFILIATES, BE LIABLE TO THE END-USER FOR ANY CONSEQUENTIAL, INCIDENTAL,
INDIRECT, SPECIAL OR EXEMPLARY DAMAGES (INCLUDING DAMAGES FOR LOSS OF BUSINESS PROFITS,
BUSINESS INTERRUPTION, LOSS OF DATA OR BUSINESS INFORMATION, AND THE LIKE) ARISING OUT
OF THE USE OF OR INABILITY TO USE THE PROGRAM OR ACCOMPANYING WRITTEN MATERIALS, EVEN
IF AUTHOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
--------------------------------------------------------------------------------------------

Thanks angel_deat for hash calculation algorithm.

Send your comments and suggestions to vasiliy73@mail.ru
With best regards, Vasiliy.